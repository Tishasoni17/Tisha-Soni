$(document).ready(function(){
    
    $("#b1").focus(function () { 
        $(this).css("background-color","red");
    });

        $("#b2").blur(function () { 
            $(this).css("background-color","blue");
            
 });
              
                
      $("#b3").keypress(function () { 
         alert($(this).val());
                    
                });
      
                
    $("#b4").keyup(function () { 
        alert($(this).val());
 });
});
                    
                
        
        
    
    