
function abc(){
    document.getElementById("new").src="../HTML/17-mile drive images.jpg"
}