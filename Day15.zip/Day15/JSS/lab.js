$(document).ready(function(){
    $("#div1").resizable();
    
});